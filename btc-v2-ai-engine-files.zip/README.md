# BTC V2 AI Research Engine

Historical Bitcoin direction model comparison, for research and paper evaluation only. No live Kalshi integration or trading execution.

Models: LightGBM, XGBoost, logistic regression, equal-weight ensemble, momentum baseline.

## Deploy to Railway
Connect this repository as a **new service**. Do not replace existing V1 or V2 services. Railway can use the included Procfile; alternatively set the start command to `uvicorn app:app --host 0.0.0.0 --port $PORT`.

`/health` is a health endpoint. `/api/evaluate` fetches Coinbase 15-minute historical candles and evaluates models on three chronological expanding-window folds, reporting accuracy and Brier scores. This may take time and depends on Coinbase API availability. This implementation has not been production-tested.

Historical results do not guarantee future performance. Coinbase spot direction is not Kalshi settlement.
